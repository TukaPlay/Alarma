package com.tuka.alarma

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmActivity : Activity() {

    companion object {
        var current: AlarmActivity? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_alarm)
        current = this

        val id = intent.getIntExtra("id", -1)
        val alarma = AlarmStore.load(this).find { it.id == id }
        findViewById<TextView>(R.id.nombre).apply {
            text = alarma?.name ?: ""
            visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
        }
        findViewById<TextView>(R.id.nota).apply {
            text = alarma?.note ?: ""
            visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
        }
        findViewById<TextView>(R.id.hora).text =
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

        findViewById<Button>(R.id.btnDetener).setOnClickListener {
            stopService(Intent(this, AlarmService::class.java))
            finish()
        }
        findViewById<TextView>(R.id.btnPosponer).setOnClickListener {
            Scheduler.snooze(this, id, 10)
            stopService(Intent(this, AlarmService::class.java))
            finish()
        }
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }
}

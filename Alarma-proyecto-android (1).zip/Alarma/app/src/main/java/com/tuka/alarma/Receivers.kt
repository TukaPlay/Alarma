package com.tuka.alarma

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val snooze = intent.getBooleanExtra("snooze", false)
        val list = AlarmStore.load(ctx)
        val a = list.find { it.id == id }

        if (!snooze) {
            if (a == null || !a.enabled) return
            if (a.days == 0) {
                a.enabled = false
                AlarmStore.save(ctx, list)
            } else {
                Scheduler.schedule(ctx, a)   // reprograma la próxima repetición
            }
        }
        ctx.startForegroundService(Intent(ctx, AlarmService::class.java).putExtra("id", id))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        AlarmStore.load(ctx).filter { it.enabled }.forEach { Scheduler.schedule(ctx, it) }
    }
}

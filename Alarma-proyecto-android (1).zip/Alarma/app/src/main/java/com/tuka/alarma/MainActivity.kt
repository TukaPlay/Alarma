package com.tuka.alarma

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import java.io.File
import java.util.Calendar

class MainActivity : Activity() {

    private val ACCENT = Color.parseColor("#8B7CFF")
    private val CARD2 = Color.parseColor("#2A2A36")
    private val MUTED = Color.parseColor("#9A9AAE")
    private val REQ_SOUND = 42
    private val SIN_SONIDO = "Sonido por defecto"

    private lateinit var lista: LinearLayout
    private var alarms = mutableListOf<Alarm>()

    // estado temporal del diálogo
    private var dlgSoundPath: String? = null
    private var dlgSoundName = SIN_SONIDO
    private var dlgSoundLabel: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        lista = findViewById(R.id.lista)
        findViewById<Button>(R.id.btnNueva).setOnClickListener { mostrarDialogo(null) }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refrescar()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun circulo(c: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(c)
    }

    private fun refrescar() {
        alarms = AlarmStore.load(this)
        alarms.sortWith(compareBy({ it.hour }, { it.minute }))
        limpiarArchivos()
        lista.removeAllViews()

        if (alarms.isEmpty()) {
            val t = TextView(this)
            t.text = "No tenés alarmas.\nTocá «Nueva alarma» para crear una."
            t.setTextColor(MUTED)
            t.textSize = 16f
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(80), 0, 0)
            lista.addView(t)
            return
        }

        for (a in alarms) {
            val v = layoutInflater.inflate(R.layout.item_alarm, lista, false)
            v.findViewById<TextView>(R.id.hora).text = a.timeText()
            v.findViewById<TextView>(R.id.nombre).apply {
                text = a.name
                visibility = if (a.name.isEmpty()) View.GONE else View.VISIBLE
            }
            v.findViewById<TextView>(R.id.nota).apply {
                text = a.note
                visibility = if (a.note.isEmpty()) View.GONE else View.VISIBLE
            }
            v.findViewById<TextView>(R.id.detalle).text = a.daysText()
            v.findViewById<TextView>(R.id.sonido).text = "♪ " + a.soundName
            v.alpha = if (a.enabled) 1f else 0.5f

            val sw = v.findViewById<Switch>(R.id.sw)
            sw.isChecked = a.enabled
            sw.setOnCheckedChangeListener { _, on ->
                a.enabled = on
                if (on) {
                    Scheduler.schedule(this, a)
                    avisar(a)
                } else {
                    Scheduler.cancel(this, a)
                }
                AlarmStore.save(this, alarms)
                v.alpha = if (on) 1f else 0.5f
            }
            v.findViewById<View>(R.id.zona).setOnClickListener { mostrarDialogo(a) }
            v.findViewById<View>(R.id.borrar).setOnClickListener { confirmarBorrado(a) }
            lista.addView(v)
        }
    }

    private fun limpiarArchivos() {
        val files = File(filesDir, "sonidos").listFiles() ?: return
        val keep = alarms.mapNotNull { it.soundPath }.toMutableSet()
        dlgSoundPath?.let { keep.add(it) }
        files.forEach { if (it.absolutePath !in keep) it.delete() }
    }

    private fun avisar(a: Alarm) {
        val total = ((a.nextTrigger() - System.currentTimeMillis()) / 60000L).toInt() + 1
        val h = total / 60
        val m = total % 60
        val txt = if (h == 0) "Suena en $m min" else "Suena en $h h $m min"
        Toast.makeText(this, txt, Toast.LENGTH_SHORT).show()
    }

    private fun confirmarBorrado(a: Alarm) {
        AlertDialog.Builder(this, R.style.DialogTheme)
            .setMessage("¿Eliminar la alarma de las ${a.timeText()}?")
            .setPositiveButton("Eliminar") { _, _ ->
                Scheduler.cancel(this, a)
                alarms.remove(a)
                AlarmStore.save(this, alarms)
                refrescar()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun mostrarDialogo(existing: Alarm?) {
        val v = layoutInflater.inflate(R.layout.dialog_alarm, null)
        val picker = v.findViewById<TimePicker>(R.id.picker)
        picker.setIs24HourView(true)
        val now = Calendar.getInstance()
        picker.hour = existing?.hour ?: now.get(Calendar.HOUR_OF_DAY)
        picker.minute = existing?.minute ?: now.get(Calendar.MINUTE)

        val etNombre = v.findViewById<EditText>(R.id.etNombre)
        val etNota = v.findViewById<EditText>(R.id.etNota)
        etNombre.setText(existing?.name ?: "")
        etNota.setText(existing?.note ?: "")

        dlgSoundPath = existing?.soundPath
        dlgSoundName = existing?.soundName ?: SIN_SONIDO
        dlgSoundLabel = v.findViewById(R.id.txtSonido)
        dlgSoundLabel?.text = "♪ $dlgSoundName"
        var days = existing?.days ?: 0

        val cont = v.findViewById<LinearLayout>(R.id.dias)
        val letras = listOf("L", "M", "M", "J", "V", "S", "D")
        letras.forEachIndexed { i, letra ->
            val t = TextView(this)
            val size = dp(38)
            val lp = LinearLayout.LayoutParams(size, size)
            lp.setMargins(dp(3), 0, dp(3), 0)
            t.layoutParams = lp
            t.text = letra
            t.gravity = Gravity.CENTER
            t.textSize = 14f
            fun pintar() {
                val on = (days and (1 shl i)) != 0
                t.background = circulo(if (on) ACCENT else CARD2)
                t.setTextColor(if (on) Color.WHITE else MUTED)
            }
            pintar()
            t.setOnClickListener {
                days = days xor (1 shl i)
                pintar()
            }
            cont.addView(t)
        }

        v.findViewById<Button>(R.id.btnSonido).setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "audio/*"
            startActivityForResult(i, REQ_SOUND)
        }
        v.findViewById<View>(R.id.btnQuitar).setOnClickListener {
            dlgSoundPath = null
            dlgSoundName = SIN_SONIDO
            dlgSoundLabel?.text = "♪ $SIN_SONIDO"
        }

        AlertDialog.Builder(this, R.style.DialogTheme)
            .setView(v)
            .setPositiveButton("Guardar") { _, _ ->
                picker.clearFocus()
                val a = existing ?: Alarm(AlarmStore.nextId(alarms), 0, 0)
                a.hour = picker.hour
                a.minute = picker.minute
                a.days = days
                a.enabled = true
                a.name = etNombre.text.toString().trim()
                a.note = etNota.text.toString().trim()
                a.soundPath = dlgSoundPath
                a.soundName = dlgSoundName
                if (existing == null) alarms.add(a)
                AlarmStore.save(this, alarms)
                Scheduler.schedule(this, a)
                avisar(a)
                refrescar()
            }
            .setNegativeButton("Cancelar", null)
            .setOnDismissListener {
                dlgSoundPath = null
                dlgSoundLabel = null
            }
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SOUND || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            var nombre = "sonido"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && idx >= 0) nombre = c.getString(idx)
            }
            val dir = File(filesDir, "sonidos")
            dir.mkdirs()
            val dest = File(dir, "s_" + System.currentTimeMillis())
            contentResolver.openInputStream(uri)!!.use { inp ->
                dest.outputStream().use { out -> inp.copyTo(out) }
            }
            dlgSoundPath = dest.absolutePath
            dlgSoundName = nombre
            dlgSoundLabel?.text = "♪ $nombre"
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo cargar ese archivo", Toast.LENGTH_LONG).show()
        }
    }
}

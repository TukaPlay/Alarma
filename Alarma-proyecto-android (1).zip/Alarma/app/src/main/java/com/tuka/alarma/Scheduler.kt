package com.tuka.alarma

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Scheduler {

    private fun pending(ctx: Context, id: Int, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .putExtra("id", id)
            .putExtra("snooze", snooze)
        val code = if (snooze) id + 1_000_000 else id
        return PendingIntent.getBroadcast(
            ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

    fun schedule(ctx: Context, a: Alarm) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(a.nextTrigger(), showIntent(ctx)), pending(ctx, a.id, false))
    }

    fun cancel(ctx: Context, a: Alarm) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, a.id, false))
    }

    fun snooze(ctx: Context, id: Int, minutes: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val t = System.currentTimeMillis() + minutes * 60_000L
        am.setAlarmClock(AlarmManager.AlarmClockInfo(t, showIntent(ctx)), pending(ctx, id, true))
    }
}

package com.tuka.alarma

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import java.io.File

class AlarmService : Service() {

    companion object {
        const val CHANNEL = "alarma_canal"
        const val NOTIF_ID = 77
        const val ACTION_STOP = "com.tuka.alarma.STOP"
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val id = intent?.getIntExtra("id", -1) ?: -1
        val alarm = AlarmStore.load(this).find { it.id == id }

        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, "Alarma", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)

        val open = PendingIntent.getActivity(
            this, id,
            Intent(this, AlarmActivity::class.java).putExtra("id", id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AlarmService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_alarm)
            .setContentTitle(alarm?.name?.takeIf { it.isNotEmpty() } ?: "⏰ Alarma")
            .setContentText(alarm?.note?.takeIf { it.isNotEmpty() } ?: alarm?.timeText() ?: "Es hora")
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(open, true)
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_alarm), "Detener", stop
                ).build()
            )
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        play(alarm?.soundPath)
        vibrate()
        handler.postDelayed({ stopSelf() }, 10 * 60 * 1000L)   // se apaga sola a los 10 min
        return START_NOT_STICKY
    }

    private fun play(path: String?) {
        stopPlayer()
        val file = path?.let { File(it) }?.takeIf { it.exists() }
        try {
            player = buildPlayer(file?.absolutePath)
        } catch (e: Exception) {
            try { player = buildPlayer(null) } catch (e2: Exception) { }
        }
    }

    private fun buildPlayer(path: String?): MediaPlayer {
        val mp = MediaPlayer()
        mp.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
        if (path != null) {
            mp.setDataSource(path)
        } else {
            mp.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        }
        mp.isLooping = true
        mp.prepare()
        mp.start()
        return mp
    }

    private fun vibrate() {
        vibrator = getSystemService(Vibrator::class.java)
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
    }

    private fun stopPlayer() {
        try { player?.stop() } catch (e: Exception) { }
        player?.release()
        player = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopPlayer()
        vibrator?.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        AlarmActivity.current?.finish()
        super.onDestroy()
    }
}

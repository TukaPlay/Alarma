package com.tuka.alarma

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Alarm(
    val id: Int,
    var hour: Int,
    var minute: Int,
    var days: Int = 0,          // bits 0..6 = Lun..Dom ; 0 = una sola vez
    var enabled: Boolean = true,
    var soundPath: String? = null,
    var soundName: String = "Sonido por defecto",
    var name: String = "",
    var note: String = ""
) {
    fun timeText(): String = "%02d:%02d".format(hour, minute)

    fun daysText(): String {
        if (days == 0) return "Una vez"
        if (days == 127) return "Todos los días"
        val names = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")
        return names.filterIndexed { i, _ -> (days and (1 shl i)) != 0 }.joinToString(" ")
    }

    fun nextTrigger(): Long {
        val now = System.currentTimeMillis()
        for (offset in 0..7) {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, offset)
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            val bit = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
            val ok = days == 0 || (days and (1 shl bit)) != 0
            if (ok && c.timeInMillis > now) return c.timeInMillis
        }
        return now + 24L * 3600L * 1000L
    }
}

object AlarmStore {
    private const val PREFS = "alarmas"
    private const val KEY = "lista"

    fun load(ctx: Context): MutableList<Alarm> {
        val out = mutableListOf<Alarm>()
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Alarm(
                        id = o.getInt("id"),
                        hour = o.getInt("hour"),
                        minute = o.getInt("minute"),
                        days = o.optInt("days", 0),
                        enabled = o.optBoolean("enabled", true),
                        soundPath = o.optString("soundPath", "").takeIf { it.isNotEmpty() },
                        soundName = o.optString("soundName", "Sonido por defecto"),
                        name = o.optString("name", ""),
                        note = o.optString("note", "")
                    )
                )
            }
        } catch (e: Exception) { }
        return out
    }

    fun save(ctx: Context, list: List<Alarm>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("hour", it.hour)
                put("minute", it.minute)
                put("days", it.days)
                put("enabled", it.enabled)
                put("soundPath", it.soundPath ?: "")
                put("soundName", it.soundName)
                put("name", it.name)
                put("note", it.note)
            })
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun nextId(list: List<Alarm>): Int = (list.maxOfOrNull { it.id } ?: 0) + 1
}
